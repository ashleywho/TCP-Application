import java.util.Date;

public class SentenceGenerator {
	 
		public String getCurrentDate() {
			
			String currentDate = new Date().toString();
			
			return currentDate;
			
		}
}
